﻿import firebase_admin
from firebase_admin import credentials, db
from colorama import Fore, Style, init
print(firebase_admin.__version__)
import firebase_admin
from firebase_admin import credentials, db



# Initialize Colorama for color output
init(autoreset=True)

# Initialize Firebase Admin SDK with Public.json
cred = credentials.Certificate('Public.json')  # Use the Public service key here
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://namecheckdb-default-rtdb.firebaseio.com/'
})

# ASCII Art and Header
def display_header():
    art = f"""
{Fore.CYAN}{Style.BRIGHT}
  _   _                      _____ _               _             
 | \ | |                    /  __ \ |             | |            
 |  \| | ___  _ __   ___ _  | /  \/ |__   ___  ___| | _____ _ __ 
 | . ` |/ _ \| '_ \ / _ (_) | |   | '_ \ / _ \/ __| |/ / _ \ '__|
 | |\  | (_) | | | |  __/_  | \__/\ | | |  __/ (__|   <  __/ |   
 \_| \_/\___/|_| |_|\___(_)  \____/_| |_|\___|\___|_|\_\___|_|   
                                                                 
{Fore.YELLOW}===============================================================
{Fore.GREEN}{Style.BRIGHT}NameChecker - Public  |  Developed by ChickenWithACrown
{Fore.YELLOW}===============================================================
"""
    print(art)

# Function to check if a name exists in the database (Public functionality)
def check_name_in_db(name):
    ref = db.reference('/names')
    query = ref.order_by_child('name').equal_to(name).get()

    if not query:
        print(f"{Fore.RED}{Style.BRIGHT}No record found for name: {name}\n")
        return

    for key, value in query.items():
        print(f"\n{Fore.GREEN}{Style.BRIGHT}Record Found for '{name}'")
        print(f"{Fore.CYAN}Status: {value['status']}")
        print(f"{Fore.YELLOW}Email: {value.get('email', 'Not available')}")
        print(f"{Fore.MAGENTA}User ID: {value.get('user_id', 'Not available')}")
        print(f"{Fore.GREEN}Record successfully retrieved.\n")

# Function to see all records with colors for each field
def see_all_names():
    ref = db.reference('/names')
    names = ref.get()

    if not names:
        print(f"{Fore.RED}{Style.BRIGHT}No records available.\n")
        return

    print(f"\n{Fore.YELLOW}=== All Records ===")
    for key, value in names.items():
        name_color = Fore.CYAN
        status_color = Fore.RED if 'Banned' in value['status'] else Fore.GREEN
        email_color = Fore.YELLOW if value.get('email', 'N/A') != 'N/A' else Fore.MAGENTA

        print(f"{name_color}Name: {value['name']}")
        print(f"{status_color}Status: {value['status']}")
        print(f"{email_color}Email: {value.get('email', 'Not available')}")
        print(f"{Fore.MAGENTA}User ID: {value.get('user_id', 'Not available')}\n")

# Public CLI to allow users to check names
def public_version():
    display_header()
    print(f"{Fore.YELLOW}Welcome to NameChecker - Public Version\n")
    while True:
        print(f"{Fore.YELLOW}1. Check a Name")
        print(f"{Fore.YELLOW}2. See All Names")
        print(f"{Fore.YELLOW}3. Exit")

        choice = input(f"{Fore.CYAN}Enter your choice (1/2/3): ").strip()

        if choice == '1':
            name = input(f"{Fore.CYAN}Enter the name to check: ").strip()
            if name:
                check_name_in_db(name)
            else:
                print(f"{Fore.RED}Please enter a valid name.")
        elif choice == '2':
            see_all_names()
        elif choice == '3':
            print(f"{Fore.RED}{Style.BRIGHT}Exiting NameChecker - Public Version. Goodbye!")
            break
        else:
            print(f"{Fore.RED}Invalid choice. Please try again.")

# Run the public version
if __name__ == "__main__":
    try:
        public_version()
    except Exception as e:
        print(f"An error occurred: {e}")
        input("\nPress Enter to exit...")
